"""Optional Elasticsearch storage and search for parsed resumes.

Install: python -m pip install elasticsearch
Set ELASTICSEARCH_URL to your reachable Elasticsearch endpoint. For secured
clusters, also set ELASTICSEARCH_API_KEY (or adapt the client for your setup).
"""

import os
from elasticsearch import Elasticsearch

INDEX_NAME = "nlp_resumes"


def get_client():
    url = os.getenv("ELASTICSEARCH_URL")
    if not url:
        raise RuntimeError("Set ELASTICSEARCH_URL to your Elasticsearch endpoint first.")
    api_key = os.getenv("ELASTICSEARCH_API_KEY")
    if api_key:
        return Elasticsearch(url, api_key=api_key)
    return Elasticsearch(url)


def ensure_index(client):
    if not client.indices.exists(index=INDEX_NAME):
        client.indices.create(
            index=INDEX_NAME,
            mappings={
                "properties": {
                    "candidate_id": {"type": "keyword"},
                    "candidate_name": {"type": "text"},
                    "emails": {"type": "keyword"},
                    "phones": {"type": "keyword"},
                    "skills": {"type": "keyword"},
                    "experiences": {"type": "text"},
                    "education": {"type": "keyword"},
                    "resume_text": {"type": "text"},
                }
            },
        )


def index_candidate(candidate_id, resume_text, parsed):
    client = get_client()
    ensure_index(client)
    document = {
        "candidate_id": candidate_id,
        "candidate_name": parsed["names"][0] if parsed["names"] else "",
        "emails": parsed["emails"],
        "phones": parsed["phones"],
        "skills": parsed["skills"],
        "experiences": parsed["experiences"],
        "education": parsed["education"],
        "resume_text": resume_text,
    }
    client.index(index=INDEX_NAME, id=candidate_id, document=document, refresh=True)
    return document


def search_candidates(query, size=10):
    client = get_client()
    response = client.search(
        index=INDEX_NAME,
        size=size,
        query={
            "multi_match": {
                "query": query,
                "fields": ["candidate_name^2", "skills^3", "experiences", "education", "resume_text"],
            }
        },
    )
    return [hit["_source"] for hit in response["hits"]["hits"]]
